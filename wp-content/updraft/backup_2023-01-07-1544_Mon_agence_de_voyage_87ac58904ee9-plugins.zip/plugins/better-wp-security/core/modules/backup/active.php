<?php

require_once( 'class-itsec-backup.php' );
$itsec_backup = new ITSEC_Backup();
$itsec_backup->run();
