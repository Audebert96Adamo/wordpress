<?php

namespace iThemesSecurity\Ban_Hosts;

use iThemesSecurity\Exception\Exception;

final class Unsupported_Operation extends \BadMethodCallException implements Exception {

}
